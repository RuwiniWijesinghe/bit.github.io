﻿using Activity12.WindowsFormApp.BusinessObject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Activity12.WindowsFormsApp.DataObject
{
    public class DataAccess
    {
        public List<Gender> GetGenderList()
        { var result = new List<Gender>();
            try
            {
                result.Add(new Gender { Id = 1, Description = "Male" });
                result.Add(new Gender { Id = 2, Description = "Female" });
            }
            catch (Exception)
            { 
                throw;
            }
            return result;
        }

        public List<Student> GetStudentList()
        {
            var result = new List<Student>();
            try {
                result.Add(new Student { Id = 1, FirstName = "FirstName 01", LastName = "LastName 01", Age = 25, GenderId = 1, Address = "WER3", NIC = "789632541V", RegistrationFees = 450.55M });
                result.Add(new Student { Id = 1, FirstName = "FirstName 02", LastName = "LastName 02", Age = 25, GenderId = 2, Address = "WER2", NIC = "789632542V", RegistrationFees = 450.55M });
                result.Add(new Student { Id = 1, FirstName = "FirstName 03", LastName = "LastName 03", Age = 25, GenderId = 2, Address = "WER4", NIC = "789632543V", RegistrationFees = 450.55M });
                result.Add(new Student { Id = 1, FirstName = "FirstName 04", LastName = "LastName 04", Age = 25, GenderId = 2, Address = "WER5", NIC = "789632544V", RegistrationFees = 450.55M });
                result.Add(new Student { Id = 1, FirstName = "FirstName 05", LastName = "LastName 05", Age = 25, GenderId = 1, Address = "WER6", NIC = "789632545V", RegistrationFees = 450.55M });
                result.Add(new Student { Id = 1, FirstName = "FirstName 06", LastName = "LastName 06", Age = 25, GenderId = 1, Address = "WER7", NIC = "789632546V", RegistrationFees = 450.55M });
                result.Add(new Student { Id = 1, FirstName = "FirstName 07", LastName = "LastName 07", Age = 25, GenderId = 1, Address = "WER7", NIC = "789632547V", RegistrationFees = 450.55M });

            }
            catch (Exception) { throw; }
            return result;
        }

    }
}
