﻿using Activity12.WindowsFormsApp.DataObject;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Activity12
{
    public partial class EditForm : Form
    {
        private DataAccess DataAccess = new DataAccess();
        private bool checkFirstName, checkLastName, checkAge, checkNIC, checkAddress, checkRegistrationFees = false;
        private int validat_int;
        private string regexNIC = @"^\d{[V|v|x|X|$";
        private string regexDecimal = @"^[1-9]\d*(\.\d+)?$";
        public EditForm()
        {
            InitializeComponent();
            Loadgender();
            LoadStudent();
        }

        private void LoadStudent()
        {
            try
            {
                dataGridView1.Rows.Clear();
                foreach (var row in DataAccess.GetStudentList())
                {
                    dataGridView1.Rows.Add("Edit", row.Id, row.FirstName, row.LastName, row.Age, DataAccess.GetGenderById(row.GenderId).Description, row.Address, row.RegistrationFees);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Loadgender()
        {
            try
            {
                cmbGender.DataSource = DataAccess.GetGenderList();
                cmbGender.DisplayMember = "Description";
            }
            catch (Exception ex)
            { MessageBox.Show(ex.Message); }
        }

        private void dataGridView1_RowLeave(object sender, DataGridViewCellEventArgs e)
        {
            textFirstName.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
            textLastName.Text = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
            textAge.Text = dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();
            cmbGender.Text = dataGridView1.Rows[e.RowIndex].Cells[5].Value.ToString();
            textNIC.Text = dataGridView1.Rows[e.RowIndex].Cells[6].Value.ToString();
            textAddress.Text = dataGridView1.Rows[e.RowIndex].Cells[7].Value.ToString();
            textRegistrationFees.Text = dataGridView1.Rows[e.RowIndex].Cells[8].Value.ToString();

        }

        private void dataGridView1_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 0)
            {
                textFirstName.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
                textLastName.Text = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
                textAge.Text = dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();
                cmbGender.Text = dataGridView1.Rows[e.RowIndex].Cells[5].Value.ToString();
                textNIC.Text = dataGridView1.Rows[e.RowIndex].Cells[6].Value.ToString();
                textAddress.Text = dataGridView1.Rows[e.RowIndex].Cells[7].Value.ToString();
                textRegistrationFees.Text = dataGridView1.Rows[e.RowIndex].Cells[8].Value.ToString();
                textFirstName.Focus();
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                errorProvider1.Clear();

                if (string.IsNullOrWhiteSpace(textFirstName.Text))
                { errorProvider1.SetError(textFirstName, "First Name is invalid.");
                    checkFirstName = false;
                }
                else
                { checkFirstName = true; }

                if (string.IsNullOrWhiteSpace(textLastName.Text))
                {
                    errorProvider1.SetError(textLastName, "Last name is invalid");
                    checkLastName = false;
                }
                else
                { checkLastName = true; }
                if (string.IsNullOrWhiteSpace(textAge.Text) || !int.TryParse(textAge.Text, out validat_int))
                {
                    errorProvider1.SetError(textAge, "Age is invalid.");
                    checkAge = false;
                }
                else
                { checkAge = true; }
                if (!Regex.Match(textNIC.Text, regexNIC, RegexOptions.IgnoreCase).Success)
                {
                    errorProvider1.SetError(textNIC, "NIC is invalid");
                    checkNIC = false;
                }
                else
                {
                    checkNIC = true;
                }
                if (string.IsNullOrWhiteSpace(textAddress.Text))
                {
                    errorProvider1.SetError(textAddress, "Address is invalid.");
                    checkAddress = false;
                }
                else
                {
                    checkAddress = true;
                }
                if (!Regex.Match(textRegistrationFees.Text, regexDecimal, RegexOptions.IgnoreCase).Success)
                {
                    errorProvider1.SetError(textRegistrationFees, "Registration fees is invalid.");
                    checkRegistrationFees = false;
                }
                else
                {
                    checkRegistrationFees = true;

                }
                if (checkFirstName == true && checkLastName == true && checkAge == true && checkNIC == true && checkAddress == true && checkRegistrationFees == true)
                {
                    MessageBox.Show("Ok");
                    TextClear();
                }
                else
                {
                    TextFocus();
                }

            }
            catch (Exception ex) {
                MessageBox.Show(ex.Message);
            }
        }

        private void TextClear()
        {
            textFirstName.Text = string.Empty;
            textLastName.Text = string.Empty;
            textAge.Text = string.Empty;
            textNIC.Text = string.Empty;
            textAddress.Text = string.Empty;
            textRegistrationFees.Text = string.Empty;
            textFirstName.Focus();
        }

        private void TextFocus()
        {
            if (checkFirstName == false)
            {
                textFirstName.Focus();
            }
            else if (checkLastName == false)
            {
                textLastName.Focus();
            }
            else if (checkAge == false)
            { textAge.Focus(); }
            else if (checkNIC == false)
            { textNIC.Focus(); }
            else if (checkAddress == false)
            { textAddress.Focus(); }
            else if (checkRegistrationFees == false)
            { textRegistrationFees.Focus(); }
        }
    }
}
