using System.Windows.Forms.Design;

namespace Activity12
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;
        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            NewForm newStudent = new NewForm();
            newStudent.MdiParent = this;
            newStudent.WindowState = FormWindowState.Maximized;
            newStudent.Show();
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            EditForm editForm = new EditForm();
            editForm.MdiParent = this;
            editForm.WindowState = FormWindowState.Maximized;
            editForm.Show();
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}